#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
oseth_live_map_v2.py
Live χάρτης λεωφορείων ΟΣΕΘ/ΟΑΣΘ από το δημόσιο telematics API του osΕΘ.

Εγκατάσταση:
    py -m pip install flask requests

Εκτέλεση:
    py busmap_all.py

Μετά άνοιξε:
    http://127.0.0.1:5000

Λειτουργίες:
- Λίστα γραμμών από /telematics-api/route
- Live οχήματα από /telematics-api/route/{routeId}/info?shapeId=...&language=el
- Επιλογή συγκεκριμένης γραμμής
- "ΟΛΑ" για όλα τα ενεργά λεωφορεία
- Στάσεις και διαδρομή όταν έχει επιλεγεί μία γραμμή
- Αυτόματη ανανέωση θέσεων
- Click σε στάση -> επόμενες αφίξεις / εκτιμώμενος χρόνος
"""

from __future__ import annotations

import re
import time
import threading
import webbrowser
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Any

import requests
import certifi
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from flask import Flask, jsonify, render_template_string, request

BASE = "https://oseth.com.gr/el/telematics-api"
LANG = "el"

# Για να μην επιβαρύνουμε άσκοπα το API.
ROUTES_CACHE_SECONDS = 6 * 60 * 60
INFO_CACHE_SECONDS = 8
ALL_MODE_CACHE_SECONDS = 15
MAX_WORKERS = 10
REQUEST_TIMEOUT = 12

app = Flask(__name__)

session = requests.Session()

# Ρητή χρήση του CA bundle του certifi. Αυτό είναι ιδιαίτερα χρήσιμο
# όταν η εφαρμογή πακετάρεται σε standalone .exe με PyInstaller.
session.verify = certifi.where()

# Αυτόματες επαναλήψεις σε προσωρινά σφάλματα σύνδεσης/server.
retry = Retry(
    total=3,
    connect=3,
    read=3,
    backoff_factor=0.5,
    status_forcelist=(429, 500, 502, 503, 504),
    allowed_methods=frozenset(["GET"]),
)
adapter = HTTPAdapter(max_retries=retry)
session.mount("https://", adapter)
session.mount("http://", adapter)

session.headers.update({
    "User-Agent": "Mozilla/5.0 OSETH-Live-Map/1.0",
    "Accept": "application/json, text/plain, */*",
    "Referer": "https://oseth.com.gr/el/anazitisi-dromologion-leoforeion/",
})

_lock = threading.Lock()
_routes_cache: dict[str, Any] = {"ts": 0.0, "data": []}
_info_cache: dict[tuple[str, str], tuple[float, dict[str, Any]]] = {}
_all_cache: dict[str, Any] = {"ts": 0.0, "data": None}
_active_lines_cache: dict[str, Any] = {"ts": 0.0, "data": []}


@dataclass(frozen=True)
class ShapeRef:
    short_name: str
    long_name: str
    color: str
    route_id: str
    shape_id: str
    headsign: str


def get_json(url: str) -> dict[str, Any]:
    r = session.get(url, timeout=REQUEST_TIMEOUT)
    r.raise_for_status()
    data = r.json()
    if isinstance(data, dict) and data.get("status_code") not in (None, 200):
        raise RuntimeError(data.get("error") or f"API status {data.get('status_code')}")
    return data


def load_routes(force: bool = False) -> list[dict[str, Any]]:
    now = time.time()
    with _lock:
        if (not force
                and _routes_cache["data"]
                and now - _routes_cache["ts"] < ROUTES_CACHE_SECONDS):
            return _routes_cache["data"]

    url = f"{BASE}/route?page=1&size=1000"
    obj = get_json(url)
    routes = obj.get("data", {}).get("routes", [])

    with _lock:
        _routes_cache["ts"] = now
        _routes_cache["data"] = routes

    return routes


def flatten_shapes(routes: list[dict[str, Any]]) -> list[ShapeRef]:
    refs: list[ShapeRef] = []
    seen: set[tuple[str, str]] = set()

    for route in routes:
        short_name = str(route.get("shortName", "")).strip()
        long_name = str(route.get("longName", "")).strip()
        color = str(route.get("color", "#1f6feb")).strip() or "#1f6feb"

        for th in route.get("tripHeadsigns") or []:
            route_id = str(th.get("routeId", "")).strip()
            shape_id = str(th.get("shapeId", "")).strip()
            headsign = str(th.get("headsign", "")).strip()

            if not route_id or not shape_id:
                continue

            key = (route_id, shape_id)
            if key in seen:
                continue
            seen.add(key)

            refs.append(ShapeRef(
                short_name=short_name,
                long_name=long_name,
                color=color,
                route_id=route_id,
                shape_id=shape_id,
                headsign=headsign,
            ))

    return refs


def get_route_info(ref: ShapeRef, force: bool = False) -> dict[str, Any]:
    key = (ref.route_id, ref.shape_id)
    now = time.time()

    with _lock:
        cached = _info_cache.get(key)
        if cached and not force and now - cached[0] < INFO_CACHE_SECONDS:
            return cached[1]

    url = (
        f"{BASE}/route/{requests.utils.quote(ref.route_id, safe='')}/info"
        f"?shapeId={requests.utils.quote(ref.shape_id, safe='')}&language={LANG}"
    )
    obj = get_json(url)
    data = obj.get("data") or {}

    with _lock:
        _info_cache[key] = (now, data)

    return data


def parse_linestring(wkt: str | None) -> list[list[float]]:
    if not wkt:
        return []

    m = re.match(r"^\s*LINESTRING\s*\((.*)\)\s*$", wkt, re.I | re.S)
    if not m:
        return []

    result: list[list[float]] = []
    for pair in m.group(1).split(","):
        parts = pair.strip().split()
        if len(parts) < 2:
            continue
        try:
            lon = float(parts[0])
            lat = float(parts[1])
            result.append([lat, lon])
        except ValueError:
            pass

    return result


def natural_line_key(name: str):
    m = re.match(r"^(\d+)(.*)$", name or "")
    if m:
        return (0, int(m.group(1)), m.group(2))
    return (1, 9999, name or "")


@app.get("/api/routes")
def api_routes():
    try:
        routes = load_routes()
        out = []
        for r in routes:
            out.append({
                "shortName": r.get("shortName"),
                "longName": r.get("longName"),
                "color": r.get("color"),
            })

        # Μοναδικές γραμμές.
        unique = {}
        for x in out:
            if x["shortName"]:
                unique[x["shortName"]] = x

        result = sorted(unique.values(), key=lambda x: natural_line_key(str(x["shortName"])))
        return jsonify({"ok": True, "routes": result})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500




@app.get("/api/all-stops")
def api_all_stops():
    """Επιστρέφει όλες τις στάσεις του δικτύου ΟΣΕΘ."""
    try:
        all_stops = []
        seen = set()
        page = 1
        size = 1000

        while page <= 20:
            r = session.get(
                f"{BASE}/stop",
                params={
                    "page": page,
                    "size": size,
                    "language": LANG,
                    "stopName": "",
                },
                timeout=REQUEST_TIMEOUT,
            )
            r.raise_for_status()
            obj = r.json()
            data = obj.get("data") or {}
            stops = data.get("stops") or []

            if not stops:
                break

            for s in stops:
                sid = str(s.get("id") or s.get("code") or "").strip()
                if not sid or sid in seen:
                    continue

                try:
                    lat = float(s["latitude"])
                    lon = float(s["longitude"])
                except (KeyError, TypeError, ValueError):
                    continue

                seen.add(sid)
                all_stops.append({
                    "id": sid,
                    "code": str(s.get("code") or sid),
                    "name": str(s.get("name") or ""),
                    "latitude": lat,
                    "longitude": lon,
                })

            total = data.get("total")
            if isinstance(total, int) and len(seen) >= total:
                break

            if len(stops) < size:
                break

            page += 1

        return jsonify({
            "ok": True,
            "count": len(all_stops),
            "stops": all_stops,
        })

    except Exception as e:
        return jsonify({
            "ok": False,
            "error": f"{type(e).__name__}: {e}"
        }), 502


@app.get("/api/active-lines")
def api_active_lines():
    """Επιστρέφει μόνο τις γραμμές που έχουν τουλάχιστον ένα ενεργό όχημα."""
    now = time.time()

    with _lock:
        if (_active_lines_cache["data"]
                and now - _active_lines_cache["ts"] < ALL_MODE_CACHE_SECONDS):
            return jsonify({
                "ok": True,
                "activeLines": _active_lines_cache["data"],
                "cached": True
            })

    try:
        routes = load_routes()
        refs = flatten_shapes(routes)

        active: set[str] = set()
        errors = 0

        def one(ref: ShapeRef):
            try:
                info = get_route_info(ref)
                has_vehicles = bool(info.get("vehicles"))
                return ref.short_name, has_vehicles, None
            except Exception as e:
                return ref.short_name, False, str(e)

        workers = min(MAX_WORKERS, max(1, len(refs)))
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = [ex.submit(one, ref) for ref in refs]
            for fut in as_completed(futures):
                short_name, has_vehicles, err = fut.result()
                if err:
                    errors += 1
                elif has_vehicles and short_name:
                    active.add(short_name)

        result = sorted(active, key=natural_line_key)

        with _lock:
            _active_lines_cache["ts"] = time.time()
            _active_lines_cache["data"] = result

        return jsonify({
            "ok": True,
            "activeLines": result,
            "errors": errors,
            "cached": False
        })

    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500



def _walk_lists(value):
    """Επιστρέφει αναδρομικά όλες τις λίστες που υπάρχουν σε JSON payload."""
    if isinstance(value, list):
        yield value
        for item in value:
            yield from _walk_lists(item)
    elif isinstance(value, dict):
        for item in value.values():
            yield from _walk_lists(item)


def _first_value(row: dict[str, Any], names: list[str]):
    lower = {str(k).lower(): v for k, v in row.items()}
    for name in names:
        value = lower.get(name.lower())
        if value not in (None, ""):
            return value
    return None


def _minutes_from_value(value: Any):
    if value is None:
        return None

    if isinstance(value, (int, float)):
        # Οι τιμές των ETA endpoints είναι συνήθως λεπτά.
        v = float(value)
        if -5 <= v <= 24 * 60:
            return max(0, int(round(v)))
        return None

    s = str(value).strip()
    if not s:
        return None

    # "5", "5 min", "5 λεπτά", κ.λπ.
    m = re.search(r"(-?\d+(?:[.,]\d+)?)\s*(?:min|mins|minute|minutes|λεπτ|′|')?", s, re.I)
    if m and re.fullmatch(r"\s*-?\d+(?:[.,]\d+)?\s*(?:min|mins|minute|minutes|λεπτ(?:ά|α)?|′|')?\s*", s, re.I):
        try:
            return max(0, int(round(float(m.group(1).replace(",", ".")))))
        except ValueError:
            pass

    # Ώρα HH:MM[:SS]
    m = re.fullmatch(r"(\d{1,2}):(\d{2})(?::(\d{2}))?", s)
    if m:
        now = datetime.now()
        target = now.replace(
            hour=int(m.group(1)),
            minute=int(m.group(2)),
            second=int(m.group(3) or 0),
            microsecond=0,
        )
        # Αν η ώρα έχει μόλις περάσει και βρισκόμαστε γύρω στα μεσάνυχτα,
        # θεωρούμε την επόμενη ημέρα.
        if target < now - timedelta(minutes=2):
            target += timedelta(days=1)
        return max(0, int((target - now).total_seconds() // 60))

    # Πλήρες timestamp.
    normalized = s.replace("Z", "+00:00")
    for parser in (
        lambda x: datetime.fromisoformat(x),
        lambda x: datetime.strptime(x, "%d/%m/%Y %H:%M:%S"),
        lambda x: datetime.strptime(x, "%Y-%m-%d %H:%M:%S"),
    ):
        try:
            dt = parser(normalized)
            if dt.tzinfo is not None:
                dt = dt.astimezone().replace(tzinfo=None)
            return max(0, int((dt - datetime.now()).total_seconds() // 60))
        except Exception:
            continue

    return None


def normalize_stop_timetable(payload: Any) -> list[dict[str, Any]]:
    """
    Μετατρέπει την απάντηση του stop timetable σε κοινή μορφή.
    Είναι ελαστικό ως προς ονόματα πεδίων ώστε να αντέχει μικρές αλλαγές
    στο JSON του ΟΣΕΘ.
    """
    candidate_lists = list(_walk_lists(payload))
    if isinstance(payload, list):
        candidate_lists.insert(0, payload)

    # Προτιμάμε λίστα από dictionaries που μοιάζει με αφίξεις/δρομολόγια.
    best: list[Any] = []
    best_score = -1

    hints = {
        "arrival", "eta", "time", "minute", "route", "line",
        "headsign", "vehicle", "trip", "shortname"
    }

    for arr in candidate_lists:
        dict_rows = [x for x in arr if isinstance(x, dict)]
        if not dict_rows:
            continue

        keys = {str(k).lower() for row in dict_rows[:10] for k in row.keys()}
        score = sum(1 for h in hints if any(h in k for k in keys))
        if score > best_score:
            best_score = score
            best = dict_rows

    if not best and isinstance(payload, dict):
        # Μερικά APIs επιστρέφουν ένα μόνο record.
        best = [payload]

    rows: list[dict[str, Any]] = []

    for row in best:
        line = _first_value(row, [
            "routeShortName", "lineShortName", "shortName",
            "line", "route", "routeName", "route_short_name",
            "routeCode", "routeId"
        ])

        headsign = _first_value(row, [
            "headsign", "tripHeadsign", "destination", "destinationName",
            "routeLongName", "longName", "description", "routeDescription"
        ])

        vehicle = _first_value(row, [
            "vehicleId", "vehicle", "vehicleCode", "veh_code", "busId", "bus"
        ])

        # Σε αρκετές απαντήσεις του ΟΣΕΘ το "route" είναι ολόκληρο object:
        # {"id": "...", "shortName": "01N", "longName": "...", "color": "..."}
        # Δεν θέλουμε να εμφανίζεται αυτούσιο στο popup.
        if isinstance(line, dict):
            route_obj = line
            line = (
                route_obj.get("shortName")
                or route_obj.get("routeShortName")
                or route_obj.get("lineShortName")
                or route_obj.get("id")
                or ""
            )
            if not headsign:
                headsign = (
                    route_obj.get("headsign")
                    or route_obj.get("longName")
                    or route_obj.get("routeLongName")
                    or ""
                )

        if isinstance(headsign, dict):
            headsign = (
                headsign.get("headsign")
                or headsign.get("longName")
                or headsign.get("name")
                or ""
            )

        if isinstance(vehicle, dict):
            vehicle = (
                vehicle.get("id")
                or vehicle.get("vehicleId")
                or vehicle.get("code")
                or ""
            )

        # Πρώτα πεδία που συνήθως σημαίνουν "λεπτά μέχρι άφιξη".
        eta_raw = _first_value(row, [
            "arrivalIn", "arrivalInMinutes", "minutes", "minutesToArrival",
            "waitingTime", "timeToArrival", "etaMinutes", "eta", "btime2"
        ])
        minutes = _minutes_from_value(eta_raw)

        # Αν δεν υπάρχει έτοιμο ETA, δοκιμάζουμε ώρα/ημερομηνία άφιξης.
        arrival_time = _first_value(row, [
            "estimatedArrivalTime", "expectedArrivalTime", "arrivalTime",
            "estimatedTime", "expectedTime", "time", "arrival"
        ])

        if minutes is None:
            minutes = _minutes_from_value(arrival_time)

        # Δεν απορρίπτουμε record μόνο επειδή δεν έχει ETA:
        # μπορεί να είναι προγραμματισμένη άφιξη.
        def clean_text(value):
            if value is None:
                return ""
            if isinstance(value, (dict, list)):
                return ""
            return str(value).strip()

        rows.append({
            "line": clean_text(line),
            "headsign": clean_text(headsign),
            "vehicle": clean_text(vehicle),
            "minutes": minutes,
            "arrival_time": clean_text(arrival_time),
        })

    # Βγάζουμε εντελώς άδεια records.
    rows = [
        x for x in rows
        if x["line"] or x["headsign"] or x["vehicle"]
        or x["minutes"] is not None or x["arrival_time"]
    ]

    rows.sort(key=lambda x: x["minutes"] if x["minutes"] is not None else 999999)
    return rows


@app.get("/api/arrivals")
def api_arrivals():
    stop_id = (request.args.get("stop_id") or "").strip()
    if not stop_id:
        return jsonify({"ok": False, "error": "Λείπει το stop_id"}), 400

    try:
        now = datetime.now()
        date_text = now.strftime("%d/%m/%Y %H:%M:%S")

        url = (
            f"{BASE}/stop/{requests.utils.quote(stop_id, safe='')}/timetable"
        )

        r = session.get(
            url,
            params={"language": LANG, "date": date_text},
            timeout=REQUEST_TIMEOUT,
        )
        r.raise_for_status()
        obj = r.json()

        if isinstance(obj, dict) and obj.get("status_code") not in (None, 200):
            raise RuntimeError(obj.get("error") or f"API status {obj.get('status_code')}")

        data = obj.get("data", obj) if isinstance(obj, dict) else obj
        arrivals = normalize_stop_timetable(data)

        return jsonify({
            "ok": True,
            "stop_id": stop_id,
            "updated": int(time.time()),
            "arrivals": arrivals,
            # Το raw payload βοηθά σε μελλοντική προσαρμογή αν αλλάξει το API.
            "raw": data,
        })

    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 502


@app.get("/api/live")
def api_live():
    selected = (request.args.get("line") or "").strip()
    all_mode = request.args.get("all") == "1"

    try:
        routes = load_routes()
        refs = flatten_shapes(routes)

        if selected:
            refs = [x for x in refs if x.short_name == selected]

        if not selected and not all_mode:
            return jsonify({"ok": True, "vehicles": [], "shapes": [], "stops": []})

        # Cache του "ΟΛΑ" επειδή μπορεί να είναι αρκετές κλήσεις.
        if all_mode and not selected:
            now = time.time()
            with _lock:
                if (_all_cache["data"] is not None
                        and now - _all_cache["ts"] < ALL_MODE_CACHE_SECONDS):
                    return jsonify(_all_cache["data"])

        vehicles = []
        shapes = []
        stops_by_id: dict[str, dict[str, Any]] = {}
        errors = []

        def one(ref: ShapeRef):
            try:
                info = get_route_info(ref)
                return ref, info, None
            except Exception as e:
                return ref, None, str(e)

        # Για μία γραμμή συνήθως 2-4 requests.
        # Στο "ΟΛΑ" χρησιμοποιούμε περιορισμένο thread pool.
        workers = min(MAX_WORKERS, max(1, len(refs)))
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = [ex.submit(one, ref) for ref in refs]
            for fut in as_completed(futures):
                ref, info, err = fut.result()
                if err:
                    errors.append({
                        "line": ref.short_name,
                        "routeId": ref.route_id,
                        "shapeId": ref.shape_id,
                        "error": err,
                    })
                    continue

                info = info or {}

                for v in info.get("vehicles") or []:
                    try:
                        lat = float(v["latitude"])
                        lon = float(v["longitude"])
                    except (KeyError, TypeError, ValueError):
                        continue

                    vehicles.append({
                        "id": str(v.get("id", "")),
                        "latitude": lat,
                        "longitude": lon,
                        "bearing": float(v.get("bearing") or 0),
                        "line": ref.short_name,
                        "headsign": ref.headsign or info.get("headsign") or "",
                        "routeId": ref.route_id,
                        "shapeId": ref.shape_id,
                        "color": ref.color,
                    })

                # Σε "ΟΛΑ" δεν στέλνουμε όλες τις γεωμετρίες/στάσεις,
                # αλλιώς το payload και ο χάρτης γίνονται πολύ βαριά.
                if selected:
                    shape_obj = info.get("shape") or {}
                    points = parse_linestring(shape_obj.get("lineString"))
                    if points:
                        shapes.append({
                            "routeId": ref.route_id,
                            "shapeId": ref.shape_id,
                            "headsign": ref.headsign or info.get("headsign") or "",
                            "color": ref.color,
                            "points": points,
                        })

                    for s in info.get("stops") or []:
                        sid = str(s.get("id") or s.get("code") or "")
                        if not sid:
                            continue
                        try:
                            stops_by_id[sid] = {
                                "id": sid,
                                "code": str(s.get("code") or sid),
                                "name": str(s.get("name") or ""),
                                "latitude": float(s["latitude"]),
                                "longitude": float(s["longitude"]),
                                "sequence": s.get("sequence"),
                            }
                        except (KeyError, TypeError, ValueError):
                            pass

        result = {
            "ok": True,
            "mode": "all" if all_mode and not selected else "line",
            "line": selected or None,
            "vehicles": vehicles,
            "shapes": shapes,
            "stops": list(stops_by_id.values()),
            "errors": errors,
            "updated": int(time.time()),
        }

        if all_mode and not selected:
            with _lock:
                _all_cache["ts"] = time.time()
                _all_cache["data"] = result

        return jsonify(result)

    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


HTML = r"""
<!doctype html>
<html lang="el">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Live λεωφορεία ΟΣΕΘ / ΟΑΣΘ</title>

<link rel="stylesheet"
 href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
 crossorigin="">

<style>
html, body {
    margin: 0;
    height: 100%;
    font-family: system-ui, -apple-system, "Segoe UI", Arial, sans-serif;
}
body {
    display: flex;
    flex-direction: column;
    background: #f5f5f5;
}
#toolbar {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 12px;
    background: white;
    border-bottom: 1px solid #ccc;
    flex-wrap: wrap;
    z-index: 1000;
}
#toolbar select, #toolbar button {
    font-size: 15px;
    padding: 6px 10px;
}
#map {
    flex: 1;
    min-height: 300px;
}
#status {
            margin-left: 0;
            font-size: 13px;
            white-space: nowrap;
            min-width: 240px;
            max-width: 330px;
            overflow: hidden;
            text-overflow: ellipsis;
            flex: 0 0 300px;
        }
#warning {
    font-size: 12px;
    color: #9a5800;
}


.bus-arrow-marker {
    position: relative;
    width: 24px;
    height: 34px;
    filter: drop-shadow(0 1px 3px rgba(255,255,255,.75))
            drop-shadow(0 2px 4px rgba(0,0,0,.45));
    transform-origin: 50% 70%;
}
.bus-arrow-marker .shaft {
    position: absolute;
    left: 9px;
    top: 14px;
    width: 6px;
    height: 17px;
    background: #1f1a1f;
    border-radius: 1px;
}
.bus-arrow-marker .head {
    position: absolute;
    left: 3px;
    top: 0;
    width: 0;
    height: 0;
    border-left: 9px solid transparent;
    border-right: 9px solid transparent;
    border-bottom: 14px solid #1f1a1f;
}
.bus-arrow-marker .fallback {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    font-size: 20px;
    line-height: 1;
}
.stop-icon {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: white;
    border: 3px solid #333;
}
.legend {
    background: rgba(255,255,255,.92);
    padding: 6px 8px;
    border-radius: 5px;
    font-size: 12px;
    line-height: 1.4;
}
.arrival-row {
    display: flex;
    gap: 10px;
    align-items: flex-start;
    padding: 6px 0;
    border-bottom: 1px solid #e7e7e7;
}
.arrival-mins {
    min-width: 48px;
    font-size: 18px;
    font-weight: 800;
}
.arrival-info {
    min-width: 0;
}
.arrival-line {
    font-size: 16px;
    font-weight: 800;
}
.small {
    font-size: 11px;
    color: #666;
}

.leaflet-popup-content {
    margin: 12px 14px;
    min-width: 300px;
    max-width: 420px;
    font-size: 14px;
    line-height: 1.35;
}
.stop-popup-title {
    font-size: 16px;
    font-weight: 800;
    margin-bottom: 3px;
}
.stop-popup-meta {
    color: #555;
    font-size: 12px;
}
.arrivals-title {
    font-size: 15px;
    font-weight: 800;
    margin: 8px 0 4px;
}
.arrivals-list {
    max-height: 310px;
    overflow-y: auto;
    padding-right: 2px;
}
.arrival-row {
    display: grid;
    grid-template-columns: 58px 1fr;
    gap: 10px;
    align-items: start;
    padding: 8px 6px;
    border: 0;
    border-bottom: 1px solid #e5e5e5;
    width: 100%;
    background: transparent;
    text-align: left;
    font: inherit;
}
.arrival-select {
    cursor: pointer;
    border-radius: 5px;
}
.arrival-select:hover {
    background: #f0f4f8;
}
.arrival-select:focus {
    outline: 2px solid #555;
    outline-offset: -2px;
}
.arrival-row:last-child {
    border-bottom: none;
}
.arrival-mins {
    min-width: 0;
    font-size: 20px;
    font-weight: 800;
    line-height: 1.1;
    color: #111;
}
.arrival-info {
    min-width: 0;
    overflow-wrap: anywhere;
}
.arrival-line {
    display: inline-block;
    font-size: 16px;
    font-weight: 800;
    margin-right: 4px;
}
.arrival-headsign {
    margin-top: 2px;
    font-size: 13px;
    line-height: 1.25;
}
.arrival-vehicle {
    margin-top: 2px;
    color: #666;
    font-size: 11px;
}
.popup-update {
    margin-top: 8px;
    padding-top: 6px;
    border-top: 1px solid #ddd;
    color: #666;
    font-size: 11px;
}


.route-legend {
    background: rgba(255,255,255,.95);
    padding: 8px 10px;
    border-radius: 6px;
    box-shadow: 0 1px 6px rgba(0,0,0,.25);
    font-size: 13px;
    line-height: 1.45;
    max-width: 340px;
}
.legend-row {
    display: flex;
    align-items: flex-start;
    gap: 7px;
    margin: 4px 0;
}
.legend-line {
    width: 26px;
    height: 5px;
    border-radius: 2px;
    flex: 0 0 auto;
    margin-top: 6px;
}
.legend-text {
    min-width: 0;
}

</style>
</head>
<body>

<div id="toolbar">
    <strong>ΟΣΕΘ Live</strong>

    <label>
        Γραμμή:
        <select id="lineSelect">
            <option value="">-- διάλεξε --</option>
        </select>
    </label>

    <button id="allBtn">ΟΛΑ τα λεωφορεία</button>
    <button id="refreshBtn">Ανανέωση τώρα</button>
    <button id="stopsBtn">Απόκρυψη στάσεων</button>

    <label>
        <input type="checkbox" id="activeOnly" checked>
        Μόνο ενεργές γραμμές
    </label>

    <label>
        κάθε
        <select id="intervalSelect">
            <option value="5">5 s</option>
            <option value="10" selected>10 s</option>
            <option value="15">15 s</option>
            <option value="20">20 s</option>
        </select>
    </label>

    
    <span id="warning"></span>
    <span id="status">Φόρτωση…</span>
</div>

<div id="map"></div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
 crossorigin=""></script>

<script>
const map = L.map('map', { preferCanvas: true }).setView([40.6401, 22.9444], 12);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

const vehicleLayer = L.layerGroup().addTo(map);
const routeLayer = L.layerGroup().addTo(map);
const stopLayer = L.layerGroup();  // στάσεις επιλεγμένης γραμμής: δεν προβάλλονται
const allStopLayer = L.layerGroup().addTo(map); // όλες οι στάσεις δικτύου

const ROUTE_COLORS = [
    "#1565c0",  // μπλε
    "#d32f2f",  // κόκκινο
    "#2e7d32",  // πράσινο
    "#7b1fa2",  // μωβ
    "#ef6c00",  // πορτοκαλί
    "#00838f",  // πετρόλ
    "#5d4037",  // καφέ
    "#c2185b"   // ροζ
];

let legendControl = null;
let currentLine = "";
let allMode = false;
let allRoutes = [];
let activeLines = new Set();
let timer = null;
let firstFit = true;
let stopsVisible = true;
let vehicleMarkers = new Map();

function safeColor(c) {
    if (/^#[0-9a-fA-F]{6}$/.test(c || "")) return c;
    return "#1f6feb";
}

function vehicleIcon(v) {
    const bearing = Number(v.bearing);
    const hasAngle = Number.isFinite(bearing);

    return L.divIcon({
        className: "",
        html: `
          <div class="bus-arrow-marker" style="${hasAngle ? `transform: rotate(${bearing}deg);` : ``}">
            ${
                hasAngle
                ? `<div class="head"></div><div class="shaft"></div>`
                : `<div class="fallback">🚌</div>`
            }
          </div>`,
        iconSize: [24, 34],
        iconAnchor: [12, 23],
        popupAnchor: [0, -24]
    });
}

function stopIcon() {
    return L.divIcon({
        className: "",
        html: '<div class="stop-icon"></div>',
        iconSize: [16,16],
        iconAnchor: [8,8]
    });
}

function escapeHtml(s) {
    return String(s ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;");
}

function fillLineSelect() {
    const sel = document.getElementById("lineSelect");
    const activeOnly = document.getElementById("activeOnly").checked;
    const oldValue = sel.value;

    sel.innerHTML = '<option value="">-- διάλεξε --</option>';

    const filtered = activeOnly
        ? allRoutes.filter(x => activeLines.has(String(x.shortName)))
        : allRoutes;

    for (const x of filtered) {
        const opt = document.createElement("option");
        opt.value = x.shortName;
        opt.textContent = `${x.shortName} — ${x.longName}`;
        sel.appendChild(opt);
    }

    if (filtered.some(x => String(x.shortName) === oldValue)) {
        sel.value = oldValue;
    } else if (currentLine && filtered.some(x => String(x.shortName) === currentLine)) {
        sel.value = currentLine;
    } else if (filtered.length) {
        currentLine = String(filtered[0].shortName);
        sel.value = currentLine;
    } else {
        currentLine = "";
    }
}

async function loadActiveLines(showStatus=true) {
    const status = document.getElementById("status");
    if (showStatus) status.textContent = "Έλεγχος ενεργών γραμμών…";

    const r = await fetch("/api/active-lines", {cache:"no-store"});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || "Σφάλμα ενεργών γραμμών");

    activeLines = new Set((j.activeLines || []).map(String));
    fillLineSelect();

    if (showStatus) {
        status.textContent = `${activeLines.size} ενεργές γραμμές αυτή τη στιγμή`;
    }
}



async function selectArrivalBus(line, vehicle) {
    line = String(line || "").trim();
    vehicle = String(vehicle || "").trim();

    if (!line) return;

    // Επιλέγουμε τη γραμμή του λεωφορείου.
    allMode = false;
    currentLine = line;

    const sel = document.getElementById("lineSelect");
    let optionExists = Array.from(sel.options).some(o => String(o.value) === line);

    // Αν η γραμμή δεν φαίνεται λόγω "Μόνο ενεργές γραμμές",
    // ξαναγεμίζουμε το select χωρίς να χάσουμε την επιλογή.
    if (!optionExists) {
        const activeOnly = document.getElementById("activeOnly");
        if (activeOnly.checked) {
            activeOnly.checked = false;
            fillLineSelect();
        }
        optionExists = Array.from(sel.options).some(o => String(o.value) === line);
    }

    if (optionExists) sel.value = line;

    // Δεν θέλουμε fit σε όλη τη γραμμή· μετά θα πάμε στο συγκεκριμένο όχημα.
    firstFit = false;
    await refreshLive(false);

    if (vehicle) {
        const vm = vehicleMarkers.get(vehicle);

        if (vm) {
            map.closePopup();
            map.setView(vm.getLatLng(), Math.max(map.getZoom(), 16));
            vm.openPopup();
            return;
        }
    }

    // Αν δεν υπάρχει vehicle ID ή δεν βρέθηκε live marker,
    // τουλάχιστον έχει ήδη επιλεγεί και εμφανιστεί η σωστή γραμμή.
    document.getElementById("status").textContent +=
        vehicle ? ` — το όχημα ${vehicle} δεν βρέθηκε στην τρέχουσα live θέση`
                : " — επιλέχθηκε η γραμμή";
}


function attachStopPopup(m, s) {
    const stopId = String(s.id || s.code || "").trim();

    const basicStopInfo =
        `<div class="stop-popup-title">${escapeHtml(s.name || "")}</div>` +
        `<div class="stop-popup-meta">Στάση ${escapeHtml(s.code || stopId)}</div>`;

    m.bindPopup(
        basicStopInfo +
        `<div style="margin-top:7px" class="small">Πάτησε για live αφίξεις.</div>`,
        {maxWidth: 390}
    );

    m.on("click", async () => {
        if (!stopId) return;

        m.setPopupContent(
            basicStopInfo +
            `<div class="arrivals-title">Επόμενες αφίξεις</div>` +
            `<span class="small">Φόρτωση…</span>`
        );

        try {
            const ar = await fetch(
                `/api/arrivals?stop_id=${encodeURIComponent(stopId)}`,
                {cache:"no-store"}
            );
            const payload = await ar.json();

            if (!ar.ok || !payload.ok) {
                throw new Error(payload.error || "Σφάλμα τηλεματικής");
            }

            const arrivals = (payload.arrivals || []).filter(a => {
                const mins = Number(a.minutes);
                return !Number.isFinite(mins) || mins <= 60;
            });

            let arrivalsHtml = "";

            if (!arrivals.length) {
                arrivalsHtml =
                    `<span class="small">Δεν υπάρχουν προβλεπόμενες αφίξεις μέσα στα επόμενα 60′.</span>`;
            } else {
                arrivalsHtml = arrivals.slice(0, 15).map(a => {
                    const mins = Number(a.minutes);
                    const minsText = Number.isFinite(mins)
                        ? (mins <= 0 ? "τώρα" : `${mins}′`)
                        : (a.arrival_time ? escapeHtml(a.arrival_time) : "—");

                    const line = String(a.line || "").trim();
                    const headsign = String(a.headsign || "").trim();
                    const vehicle = String(a.vehicle || "").trim();

                    return (
                        `<button type="button" class="arrival-row arrival-select" ` +
                        `data-line="${escapeHtml(line)}" data-vehicle="${escapeHtml(vehicle)}" ` +
                        `title="Επιλογή λεωφορείου">` +
                          `<div class="arrival-mins">${escapeHtml(minsText)}</div>` +
                          `<div class="arrival-info">` +
                            (line
                              ? `<div><span class="arrival-line">${escapeHtml(line)}</span></div>`
                              : ``) +
                            (headsign
                              ? `<div class="arrival-headsign">${escapeHtml(headsign)}</div>`
                              : ``) +
                            (vehicle
                              ? `<div class="arrival-vehicle">Όχημα ${escapeHtml(vehicle)} · πάτησε για επιλογή</div>`
                              : `<div class="arrival-vehicle">Πάτησε για επιλογή γραμμής</div>`) +
                          `</div>` +
                        `</button>`
                    );
                }).join("");
            }

            const when = new Date((payload.updated || Date.now()/1000) * 1000);

            m.setPopupContent(
                basicStopInfo +
                `<div class="arrivals-title">Επόμενες αφίξεις</div>` +
                `<div class="arrivals-list">${arrivalsHtml}</div>` +
                `<div class="popup-update">` +
                `Τηλεματική ΟΣΕΘ · ενημέρωση ${when.toLocaleTimeString("el-GR")}` +
                `</div>`
            );

        } catch(e) {
            console.error("Σφάλμα αφίξεων:", e);
            m.setPopupContent(
                basicStopInfo +
                `<div class="arrivals-title">Επόμενες αφίξεις</div>` +
                `<span class="small">Αδυναμία φόρτωσης αφίξεων: ${escapeHtml(e.message)}</span>`
            );
        }
    });
}


async function loadAllStops() {
    const status = document.getElementById("status");

    try {
        status.textContent = "Φόρτωση όλων των στάσεων…";

        const r = await fetch("/api/all-stops", {cache:"no-store"});
        const j = await r.json();

        if (!r.ok || !j.ok) {
            throw new Error(j.error || "Σφάλμα στάσεων");
        }

        allStopLayer.clearLayers();

        for (const s of j.stops || []) {
            const m = L.marker(
                [s.latitude, s.longitude],
                {
                    icon: stopIcon(),
                    title: `${s.code} — ${s.name}`,
                    zIndexOffset: 100
                }
            ).addTo(allStopLayer);

            attachStopPopup(m, s);
        }

        if (!stopsVisible && map.hasLayer(allStopLayer)) {
            map.removeLayer(allStopLayer);
        }

        status.textContent = `${j.count || 0} στάσεις φορτώθηκαν`;

    } catch(e) {
        status.textContent = "Σφάλμα φόρτωσης στάσεων: " + e;
    }
}


async function loadRoutes() {
    const status = document.getElementById("status");
    try {
        status.textContent = "Φόρτωση γραμμών…";

        const r = await fetch("/api/routes");
        const j = await r.json();
        if (!j.ok) throw new Error(j.error || "Σφάλμα");

        allRoutes = j.routes || [];

        await loadActiveLines(true);

        if (currentLine) {
            await refreshLive(true);
        }
    } catch(e) {
        status.textContent = "Σφάλμα φόρτωσης γραμμών: " + e;
    }
}

async function refreshLive(forceFit=false) {
    const status = document.getElementById("status");
    const warning = document.getElementById("warning");

    let url;
    if (allMode) {
        url = "/api/live?all=1";
        warning.textContent = "Η προβολή ΟΛΑ κάνει πολλές κλήσεις στο API· ανανεώνεται πιο αραιά από cache.";
    } else if (currentLine) {
        url = "/api/live?line=" + encodeURIComponent(currentLine);
        warning.textContent = "";
    } else {
        return;
    }

    status.textContent = "Ενημέρωση…";

    try {
        const r = await fetch(url, {cache:"no-store"});
        const j = await r.json();
        if (!j.ok) throw new Error(j.error || "Σφάλμα API");

        vehicleLayer.clearLayers();
        vehicleMarkers.clear();
        routeLayer.clearLayers();
        stopLayer.clearLayers();

        const bounds = [];
        const legendRows = [];

        if (legendControl) {
            map.removeControl(legendControl);
            legendControl = null;
        }

        (j.shapes || []).forEach((s, index) => {
            const color = ROUTE_COLORS[index % ROUTE_COLORS.length];

            const p = L.polyline(s.points, {
                color: color,
                weight: 5,
                opacity: .82
            }).addTo(routeLayer);

            p.bindPopup(
                `<b>Γραμμή ${escapeHtml(currentLine)}</b><br>` +
                `${escapeHtml(s.headsign || "Διαδρομή")}`
            );

            for (const q of s.points) bounds.push(q);

            legendRows.push(
                `<div class="legend-row">` +
                    `<span class="legend-line" style="background:${color}"></span>` +
                    `<span class="legend-text">${escapeHtml(s.headsign || ("Διαδρομή " + (index + 1)))}</span>` +
                `</div>`
            );
        });

        if (legendRows.length) {
            legendControl = L.control({position: "bottomright"});
            legendControl.onAdd = function() {
                const div = L.DomUtil.create("div", "route-legend");
                div.innerHTML =
                    `<b>Γραμμή ${escapeHtml(currentLine)}</b>` +
                    legendRows.join("");
                L.DomEvent.disableClickPropagation(div);
                L.DomEvent.disableScrollPropagation(div);
                return div;
            };
            legendControl.addTo(map);
        }

        for (const s of j.stops || []) {
            const m = L.marker(
                [s.latitude, s.longitude],
                {icon: stopIcon(), title: s.name}
            ).addTo(stopLayer);

            const stopId = String(s.id || s.code || "").trim();
            const basicStopInfo =
                `<div class="stop-popup-title">${escapeHtml(s.name)}</div>` +
                `<div class="stop-popup-meta">` +
                `Στάση ${escapeHtml(s.code)} · σειρά ${escapeHtml(s.sequence)}` +
                `</div>`;

            m.bindPopup(
                basicStopInfo +
                `<div style="margin-top:7px" class="small">Πάτησε για live αφίξεις.</div>`,
                {maxWidth: 390}
            );

            m.on("click", async () => {
                if (!stopId) return;

                m.setPopupContent(
                    basicStopInfo +
                    `<div class="arrivals-title">Επόμενες αφίξεις</div>` +
                    `<span class="small">Φόρτωση…</span>`
                );

                try {
                    const ar = await fetch(
                        `/api/arrivals?stop_id=${encodeURIComponent(stopId)}`,
                        {cache:"no-store"}
                    );
                    const payload = await ar.json();

                    if (!ar.ok || !payload.ok) {
                        throw new Error(payload.error || "Σφάλμα τηλεματικής");
                    }

                    const arrivals = (payload.arrivals || []).filter(a => {
                        const mins = Number(a.minutes);
                        return !Number.isFinite(mins) || mins <= 60;
                    });
                    let arrivalsHtml = "";

                    if (!arrivals.length) {
                        arrivalsHtml =
                            `<span class="small">Δεν υπάρχουν προβλεπόμενες αφίξεις μέσα στα επόμενα 60′.</span>`;
                    } else {
                        arrivalsHtml = arrivals.slice(0, 12).map(a => {
                            const mins = Number(a.minutes);
                            const minsText = Number.isFinite(mins)
                                ? (mins <= 0 ? "τώρα" : `${mins}′`)
                                : (a.arrival_time ? escapeHtml(a.arrival_time) : "—");

                            const line = String(a.line || "").trim();
                            const headsign = String(a.headsign || "").trim();
                            const vehicle = String(a.vehicle || "").trim();

                            const selected = String(currentLine || "").trim();
                            const isOther =
                                line && selected && line !== selected;

                            return (
                                `<button type="button" class="arrival-row arrival-select" ` +
                                `data-line="${escapeHtml(line)}" data-vehicle="${escapeHtml(vehicle)}" ` +
                                `title="Επιλογή λεωφορείου">` +
                                  `<div class="arrival-mins">${escapeHtml(minsText)}</div>` +
                                  `<div class="arrival-info">` +
                                    (line
                                      ? `<div><span class="arrival-line">${escapeHtml(line)}</span>` +
                                        (isOther ? `<span class="small">(άλλη γραμμή)</span>` : ``) +
                                        `</div>`
                                      : ``) +
                                    (headsign
                                      ? `<div class="arrival-headsign">${escapeHtml(headsign)}</div>`
                                      : ``) +
                                    (vehicle
                                      ? `<div class="arrival-vehicle">Όχημα ${escapeHtml(vehicle)} · πάτησε για επιλογή</div>`
                                      : `<div class="arrival-vehicle">Πάτησε για επιλογή γραμμής</div>`) +
                                  `</div>` +
                                `</button>`
                            );
                        }).join("");
                    }

                    const when = new Date((payload.updated || Date.now()/1000) * 1000);

                    m.setPopupContent(
                        basicStopInfo +
                        `<div class="arrivals-title">Επόμενες αφίξεις</div>` +
                        `<div class="arrivals-list">${arrivalsHtml}</div>` +
                        `<div class="popup-update">` +
                        `Τηλεματική ΟΣΕΘ · ενημέρωση ` +
                        `${when.toLocaleTimeString("el-GR")}` +
                        `</div>`
                    );

                } catch(e) {
                    console.error("Σφάλμα αφίξεων:", e);
                    m.setPopupContent(
                        basicStopInfo +
                        `<div class="arrivals-title">Επόμενες αφίξεις</div>` +
                        `<span class="small">Αδυναμία φόρτωσης αφίξεων: ${escapeHtml(e.message)}</span>`
                    );
                }
            });

            bounds.push([s.latitude, s.longitude]);
        }

        // Η προβολή στάσεων γίνεται από το allStopLayer.
        if (stopsVisible) {
            if (!map.hasLayer(allStopLayer)) allStopLayer.addTo(map);
        } else {
            if (map.hasLayer(allStopLayer)) map.removeLayer(allStopLayer);
        }

        for (const v of j.vehicles || []) {
            const m = L.marker(
                [v.latitude, v.longitude],
                {
                    icon: vehicleIcon(v),
                    title: `Γραμμή ${v.line} - Όχημα ${v.id}`,
                    zIndexOffset: 1000
                }
            ).addTo(vehicleLayer);

            m.bindPopup(
                `<b>Γραμμή ${escapeHtml(v.line)}</b><br>` +
                `Όχημα: ${escapeHtml(v.id)}<br>` +
                `${escapeHtml(v.headsign)}<br>` +
                `Bearing: ${Number(v.bearing || 0).toFixed(1)}°<br>` +
                `${Number(v.latitude).toFixed(6)}, ${Number(v.longitude).toFixed(6)}`
            );

            vehicleMarkers.set(String(v.id || "").trim(), m);
            bounds.push([v.latitude, v.longitude]);
        }

        const when = new Date((j.updated || Math.floor(Date.now()/1000))*1000);
        status.textContent =
            `${j.vehicles?.length || 0} ενεργά λεωφορεία` +
            (!allMode && currentLine ? ` στη γραμμή ${currentLine}` : "") +
            ` — ${when.toLocaleTimeString("el-GR")}` +
            (j.errors?.length ? ` — ${j.errors.length} σφάλματα επιμέρους διαδρομών` : "");

        if ((forceFit || firstFit) && bounds.length) {
            map.fitBounds(bounds, {padding:[25,25], maxZoom:15});
            firstFit = false;
        }

    } catch(e) {
        status.textContent = "Σφάλμα live ενημέρωσης: " + e;
    }
}

function resetTimer() {
    if (timer) clearInterval(timer);
    const sec = Number(document.getElementById("intervalSelect").value || 30);

    timer = setInterval(() => {
        refreshLive(false);
    }, sec * 1000);
}


document.addEventListener("click", async e => {
    const row = e.target.closest(".arrival-select");
    if (!row) return;

    e.preventDefault();
    e.stopPropagation();

    const line = row.dataset.line || "";
    const vehicle = row.dataset.vehicle || "";

    row.disabled = true;
    const oldTitle = row.title;
    row.title = "Επιλογή…";

    try {
        await selectArrivalBus(line, vehicle);
    } finally {
        row.disabled = false;
        row.title = oldTitle;
    }
});


document.getElementById("lineSelect").addEventListener("change", async e => {
    currentLine = e.target.value;
    allMode = false;
    firstFit = true;
    await refreshLive(true);
});

document.getElementById("allBtn").addEventListener("click", async () => {
    currentLine = "";
    allMode = true;
    document.getElementById("lineSelect").value = "";
    firstFit = true;
    await refreshLive(true);
});

document.getElementById("refreshBtn").addEventListener("click", async () => {
    try {
        await loadActiveLines(false);
    } catch(e) {}
    await refreshLive(false);
});

document.getElementById("activeOnly").addEventListener("change", async () => {
    fillLineSelect();
    allMode = false;
    firstFit = true;
    if (currentLine) await refreshLive(true);
});

document.getElementById("stopsBtn").addEventListener("click", () => {
    stopsVisible = !stopsVisible;
    const btn = document.getElementById("stopsBtn");
    btn.textContent = stopsVisible ? "Απόκρυψη στάσεων" : "Εμφάνιση στάσεων";

    if (stopsVisible) {
        if (!map.hasLayer(allStopLayer)) allStopLayer.addTo(map);
    } else {
        if (map.hasLayer(allStopLayer)) map.removeLayer(allStopLayer);
    }
});

document.getElementById("intervalSelect").addEventListener("change", resetTimer);

loadAllStops();
loadRoutes();
resetTimer();
</script>

</body>
</html>
"""


@app.get("/")
def index():
    return render_template_string(HTML)


if __name__ == "__main__":
    from waitress import serve

    url = "http://127.0.0.1:5000"

    print()
    print("ΟΣΕΘ Live Map")
    print(f"Άνοιγμα στον browser: {url}")
    print("Κλείσε αυτό το παράθυρο για τερματισμό.")
    print()

    # Ανοίγει αυτόματα τον προεπιλεγμένο browser λίγο μετά την εκκίνηση.
    threading.Timer(1.2, lambda: webbrowser.open(url)).start()

    # Production-grade local WSGI server.
    serve(app, host="127.0.0.1", port=5000, threads=8)
