OSETH Live Map - EXE Builder v2

Η v2 προσθέτει:
- explicit certifi CA certificate bundle
- retries σε προσωρινά HTTPS/network errors
- PyInstaller collect-all certifi
- πιο αναλυτικό μήνυμα σφάλματος σύνδεσης

Βήματα:
1. Αποσυμπίεσε το ZIP.
2. Τρέξε build_exe_v2.bat.
3. Το EXE θα δημιουργηθεί στο:
   dist\OSETH_Live_Map_v2.exe

Δοκίμασε αυτό το EXE αντί για το προηγούμενο.
