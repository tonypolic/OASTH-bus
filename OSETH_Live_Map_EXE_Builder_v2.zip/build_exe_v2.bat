@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo   OSETH Live Map - Build standalone EXE v2
echo ==========================================
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Δεν βρέθηκε το Python Launcher "py".
    pause
    exit /b 1
)

echo [1/4] Ενημέρωση pip...
py -m pip install --upgrade pip
if errorlevel 1 goto :fail

echo.
echo [2/4] Εγκατάσταση πακέτων...
py -m pip install -r requirements_v2.txt pyinstaller
if errorlevel 1 goto :fail

echo.
echo [3/4] Δημιουργία EXE...
py -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onefile ^
  --console ^
  --name "OSETH_Live_Map_v2" ^
  --collect-all flask ^
  --collect-all waitress ^
  --collect-all certifi ^
  --hidden-import urllib3 ^
  --hidden-import charset_normalizer ^
  --hidden-import idna ^
  oseth_live_map_v2.py
if errorlevel 1 goto :fail

echo.
echo [4/4] Ολοκληρώθηκε.
echo.
echo Το EXE βρίσκεται εδώ:
echo   %CD%\dist\OSETH_Live_Map_v2.exe
echo.
pause
exit /b 0

:fail
echo.
echo [ERROR] Η δημιουργία του EXE απέτυχε.
pause
exit /b 1
